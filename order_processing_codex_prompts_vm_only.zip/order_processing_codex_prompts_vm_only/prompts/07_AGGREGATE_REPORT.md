# 07 — Aggregate All Reports into One Final Status Packet

You are Codex running on the VM. Work in `/data/order-processing`.

## Goal
Combine the outputs from prompts 01–06 (and any other files under the run folder) into:
- one consolidated readiness report
- a single “next actions” list in order

## Output requirements
Write outputs to: `/data/order-processing/_codex_predeploy/${OP_RUN_ID}/`
- `REPORT_FINAL.md` (consolidated)
- `STATUS.json` (summary)

Then print a **Paste‑Back Report** block (<=200 lines) with:
- Pass/Fail table
- Top 10 next actions
- Paths to key logs

If `OP_RUN_ID` is not set, attempt to find the most recent run folder under `/data/order-processing/_codex_predeploy/`
and use that.

## Steps
1) Identify the run folder:
   - `/data/order-processing/_codex_predeploy/${OP_RUN_ID}/`
2) Read:
   - `01_VM_FOUNDATION_REPORT.md`
   - `02_AZURE_MI_ACCESS_REPORT.md`
   - `03_FOUNDRY_MODEL_SMOKES_REPORT.md`
   - `04_ZOHO_SANDBOX_SMOKES_REPORT.md`
   - `05_TEAMS_READINESS_REPORT.md`
   - `06_TAB_READINESS_REPORT.md`
3) Build consolidated report with:
   - current state summary
   - what’s proven working
   - blockers (ordered)
   - next actions (ordered, with owners: VM / Azure(360innovate) / Tenant(Ashtad))
4) Write `STATUS.json` with machine-readable fields:
   - docker_ok, pm2_ok, nginx_ok, tls_ok, azure_cli_ok, mi_ok, foundry_ok, zoho_ok, teams_ready, tab_ready
5) Print Paste‑Back Report block.
