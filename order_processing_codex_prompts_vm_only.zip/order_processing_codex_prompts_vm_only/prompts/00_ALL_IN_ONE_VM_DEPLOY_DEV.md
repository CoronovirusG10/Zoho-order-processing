# 00 — ALL IN ONE: VM Deploy (Dev) + Verification + Report

You are Codex running on a VM. Work in `/data/order-processing`.

## Goal
Execute the **VM-only dev deployment/verification** steps for the order-processing system and produce a report.

This is a dev/sandbox. You may perform write actions (start/restart services, edit configs if required), but:
- do not print secrets (redact tokens/keys)
- do not delete data
- do not create Zoho orders unless `ALLOW_ZOHO_WRITE=1`

## Output requirements (mandatory)
1) Create folder: `/data/order-processing/_codex_predeploy/${OP_RUN_ID}/`
2) Write:
   - `REPORT_FINAL.md` (main report)
   - `COMMANDS.log` (all commands executed)
   - `STATUS.json` (machine-readable status summary)
3) At the end, print a **Paste‑Back Report** markdown block that is <= 200 lines and includes:
   - run id
   - git commit
   - docker/temporal status
   - pm2 status
   - nginx status + TLS status
   - key endpoints results
   - model connectivity summary
   - zoho connectivity summary
   - manual steps remaining (Teams tenant)

If `OP_RUN_ID` is not set, set it to UTC timestamp and export it.

## Step 0 — Setup logging helpers
- `set -euo pipefail`
- define a helper `logcmd()` that appends the command to COMMANDS.log and then runs it.
- all commands must be executed via `logcmd`.

## Step 1 — Project and system discovery (facts)
Run and capture (sanitise outputs as needed):
- `whoami`, `hostname`, `date -Is`, `uname -a`
- `cd /data/order-processing`
- `ls -la`
- `git rev-parse HEAD` and `git status --porcelain=v1` (if git)
- inventory key docs (first 80 lines each):
  - `README.md`
  - `SOLUTION_DESIGN.md`
  - `MVP_AND_HOWTO.md`
  - `CROSS_TENANT_TEAMS_DEPLOYMENT.md`
  - `WHAT_WE_NEED_TO_KNOW.md`
- find service/config roots:
  - `find app -maxdepth 4 -type f -name 'docker-compose*.yml' -o -name 'ecosystem*.config*' -o -name 'nginx*.conf' -o -name 'package.json' | sort`

## Step 2 — Bring up Temporal + PostgreSQL (Docker)
- Locate the temporal compose file (expected: `app/services/workflow/docker-compose.temporal.yml`).
- Run:
  - `docker compose -f <file> up -d`
  - `docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}'`
  - `docker compose -f <file> ps`
- Verify Temporal server reachable locally:
  - `nc -zv 127.0.0.1 7233`
  - `curl -fsS http://127.0.0.1:8080/ | head`

If anything fails, show the last 200 lines of the relevant container logs and propose the fix; apply the fix if it’s safe.

## Step 3 — PM2 services
Goal: ensure `workflow-api`, `workflow-worker`, and `teams-bot` are running.

- Detect how services are started:
  - look for `ecosystem.config.*`, `pm2` scripts in package.json, or existing pm2 processes.
- If pm2 isn’t installed, install it globally (Node dev sandbox ok).
- Start or restart services as intended by repo config.
- Record:
  - `pm2 ls`
  - `pm2 describe <proc>` for each
  - last 200 lines of logs for each (redact secrets):
    - `pm2 logs <proc> --lines 200 --nostream`

## Step 4 — nginx and TLS
- Check nginx:
  - `sudo nginx -t`
  - `systemctl status nginx --no-pager -l | head -n 80`
- Locate active site config and verify routes match the VM architecture:
  - `/api/messages -> localhost:3978`
  - `/api/* -> localhost:3000`
  - `/temporal/ -> localhost:8080`
  - `/health -> localhost:3000/health`
- If config is wrong, fix it and reload nginx:
  - `sudo systemctl reload nginx`
- TLS check:
  - `curl -k -I https://pippai-vm.360innovate.com/health || true`
  - `curl -I https://pippai-vm.360innovate.com/health || true`
  - If TLS fails, check whether certbot is installed and whether a cert exists:
    - `sudo certbot certificates || true`
  - Do not request new certs automatically unless user already approved in the CLI.

## Step 5 — Health and routing verification
Run:
- `curl -fsS http://127.0.0.1:3000/health`
- `curl -fsS http://127.0.0.1:3978/api/messages -I || true` (endpoint may require POST)
- External checks (if DNS works):
  - `curl -fsS https://pippai-vm.360innovate.com/health`
  - `curl -fsS https://pippai-vm.360innovate.com/temporal/ | head`

## Step 6 — Azure baseline + Managed Identity checks (best-effort)
- Check Azure CLI availability: `az version`
- Try MI login:
  - `az login --identity` (if this fails, capture error and continue)
- Capture:
  - `az account show` (redact subscription/tenant ids if needed)
  - `az group show -n pippai-rg -o jsonc || true`
  - `az keyvault show -n pippai-keyvault-dev -g pippai-rg -o jsonc || true`
  - `az storage account show -n pippaistoragedev -g pippai-rg -o jsonc || true`
  - `az cosmosdb show -n cosmos-visionarylab -g pippai-rg -o jsonc || true`

Data-plane sanity tests (safe):
- Key Vault: list secret names only:
  - `az keyvault secret list --vault-name pippai-keyvault-dev -o table || true`
- Storage: list containers (auth-mode login):
  - `az storage container list --account-name pippaistoragedev --auth-mode login -o table || true`

If any access is denied, include the exact RBAC role needed (do not change RBAC automatically).

## Step 7 — Foundry/AI model connectivity (smoke tests)
Use repo config to locate AI endpoints/keys (do not print secrets).
- Find any “ai config” files and env vars usage:
  - `rg -n "(foundry|azure ai|azure_openai|openai|anthropic|gemini|xai|grok|deepseek|cohere|mistral)" app -S || true`

Run smoke tests:
- Prefer existing scripts (`npm run smoke:*`, `node scripts/*`, etc). If none exist:
  - Create a temporary script under `/tmp` to call:
    - embeddings: Cohere multilingual with an English+Farsi sample
    - one chat completion: gpt-5.1 or o3 (Azure Foundry)
  - Validate the response is parseable JSON if strict mode is expected.

Output must include:
- which models were actually reachable
- whether structured JSON was enforced successfully

## Step 8 — Zoho Books sandbox connectivity (smoke tests)
Rules:
- Do not print token/secret values.
- Default to GET-only checks.
- Only create a draft order if `ALLOW_ZOHO_WRITE=1`.

Steps:
- Locate Zoho config (token file and/or KV references).
- Confirm EU endpoints are used.
- GET checks:
  - Organisations (or a light endpoint your integration uses)
  - Items list (first page only)
  - Contacts/customers search (if implemented)

If `ALLOW_ZOHO_WRITE=1`, create a **clearly labelled TEST draft** using a known test customer+item from config (or skip if not available).

## Step 9 — Teams artefacts readiness (manual steps output)
- Find Teams app package files (manifest/icons).
- Validate:
  - messaging endpoint matches `https://pippai-vm.360innovate.com/api/messages`
  - personal scope bot enabled
  - file upload support enabled if expected
- Produce a “Manual steps for Ashtad tenant” section:
  - app registration items
  - Azure Bot resource + Teams channel wiring
  - manifest upload/install

## Step 10 — Personal Tab readiness
- Detect tab code/build instructions.
- If build artefacts exist, verify nginx route.
- If not, document what to build and where to host (nginx static vs workflow-api route).

## Step 11 — Final report writing
Write `REPORT_FINAL.md` with:
- Summary table: Step -> Pass/Fail/Needs Action
- Blockers
- Exact next actions in order
- Paths to logs / evidence
Also write `STATUS.json` (a compact summary object) for easy copy/paste.

Finally print the **Paste‑Back Report** block.
